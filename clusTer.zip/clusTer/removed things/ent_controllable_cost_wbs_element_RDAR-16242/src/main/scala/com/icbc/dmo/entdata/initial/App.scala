package com.icbc.dmo.entdata.initial

import org.apache.log4j.{Logger, LogManager}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import com.icbc.{util_base, util_dao}
import com.icbc.dmo.entdata.Query.q_WbsElement
import com.icbc.dmo.entdata.SourcetoStaging.s_CdwProjects
import com.icbc.dmo.entdata.transformations

object App {

  /**
   * Enterprise pipeline for wbs_element table of controllable cost project
   *
   * @param args application parameters
   */

  def main(args: Array[String]): Unit = {
    val log: Logger = LogManager.getLogger(this.getClass.getName)
    implicit val (spark, config) = util_base.initSparkPipeline(args, "dmo", "wbs_element")
    log.debug("SparkSession Started")

    // wbs_element
    val cluster_landing_staging_path = config.getString("landing_staging_path")
    val wbsSourceFile = spark.read.textFile(cluster_landing_staging_path + "sap_controllable_cost/sap_cdw_projects-data").toDF()
    val staging_wbsElement = s_CdwProjects.parser(spark, wbsSourceFile).persist()
    val queryApplied_wbsElement = q_WbsElement.builder(spark, staging_wbsElement)

    val nullability_fixer1 = transformations.setNullableStateOfColumn(queryApplied_wbsElement,"WBS_ELEMENT_ID",false)
    val nullability_fixer2 = transformations.setNullableStateOfColumn(nullability_fixer1,"PROJECT_HIERARCHY",false)
    val nullability_fixer3 = transformations.setNullableStateOfColumn(nullability_fixer2,"PROJECT_TYPE",true)
    val nullability_fixer4 = transformations.setNullableStateOfColumn(nullability_fixer3,"PROJECT_TYPE_NAME",true)
    val withBDMfields = transformations.addBDMFields(nullability_fixer4)
    val finalDF = withBDMfields

    val wbsEnterpriseMetaDatafromDDL = util_dao.parquet(saveMode = SaveMode.Overwrite)
      .getOrCreateTable("entdata_finance", "control_cost_wbs_element")
    val wbsTargetColumns = util_base.getSelectSQL(wbsEnterpriseMetaDatafromDDL.getSchema)
    wbsEnterpriseMetaDatafromDDL.save(finalDF.select(wbsTargetColumns: _*))
  }
}
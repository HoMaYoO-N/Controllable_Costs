CREATE TABLE control_cost_basic_optional_rule(
    COST_CENTRE_ID int,
    RULE_START_PERIOD int,
    RULE_END_PERIOD int,
    PERCENTAGE_VERSION int,
    PRODUCT_TYPE_ID int,
    BASIC_OPTIONAL_PERCENTAGE double,
    AMOUNT_TYPE int,
    bdm_create_ts timestamp,
    bdm_datazap_id string,
    bdm_delete_ind string
)
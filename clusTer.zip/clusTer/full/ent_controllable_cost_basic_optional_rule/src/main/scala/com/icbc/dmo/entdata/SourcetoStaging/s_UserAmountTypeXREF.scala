package com.icbc.dmo.entdata.SourcetoStaging

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, substring, to_timestamp, trim}

object s_UserAmountTypeXREF {
//  def parser(spark: SparkSession, df: DataFrame): DataFrame = {
//    val phase1 =
//    val parsedDF = phase2
//    return parsedDF
//  }
}

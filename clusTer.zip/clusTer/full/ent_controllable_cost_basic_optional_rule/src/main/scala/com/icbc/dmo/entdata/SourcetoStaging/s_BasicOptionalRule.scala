package com.icbc.dmo.entdata.SourcetoStaging

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, substring, to_timestamp, trim}

object s_BasicOptionalRule {
  def parser(spark: SparkSession, df: DataFrame): DataFrame = {
    val phase1 =
      df.withColumn("COST_CENTRE", trim(substring(df("value"), 1, 10)).cast("String"))
        .withColumn("PERCENTAGE_VERSION", trim(substring(df("value"), 11, 3)).cast("Integer"))
        .withColumn("RULE_YEAR", trim(substring(df("value"), 14, 4)).cast("Integer"))
        .withColumn("RULE_PERIOD", trim(substring(df("value"), 18, 3)).cast("Integer"))
        .withColumn("BON_VALUE_TYPE", trim(substring(df("value"), 21, 1)).cast("Integer"))
        .withColumn("BON_PLAN_VERSION", trim(substring(df("value"), 22, 3)).cast("String"))
        .withColumn("BASIC_PERCENTAGE", trim(substring(df("value"), 25, 19)).cast("Double"))
        .withColumn("BASIC_UNIT_OF_MEASURE", trim(substring(df("value"), 44, 1)).cast("String"))
        .withColumn("OPTIONAL_PERCENTAGE", trim(substring(df("value"), 45, 19)).cast("Double"))
        .withColumn("OPTIONAL_UNIT_OF_MEASURE", trim(substring(df("value"), 64, 1)).cast("String"))
        .withColumn("NON_INSURANCE_PERCENTAGE", trim(substring(df("value"), 65, 19)).cast("Double"))
        .withColumn("NON_INSURANCE_UNIT_OF_MEASURE", trim(substring(df("value"), 84, 1)).cast("String"))
        .withColumn("SAP_EXTRACT_DATE_TIME", trim(substring(df("value"), 85, 10)))
        .drop("value")
    val phase2 =
      phase1.withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(phase1("SAP_EXTRACT_DATE_TIME"), "/",
        "-")))
    val parsedDF = phase2
    return parsedDF
  }
}

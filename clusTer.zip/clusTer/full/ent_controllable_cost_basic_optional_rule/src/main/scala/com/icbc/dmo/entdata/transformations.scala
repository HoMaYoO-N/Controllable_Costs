package com.icbc.dmo.entdata

import org.apache.spark.sql.functions.{bround, col, lit, when}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

import com.icbc.util_datetime

object transformations {
  /**
   * Adds BDM fields to the dataframe
   *
   * @param df The input dataframe to which BDM fields are to be added
   * @return The new dataframe with BDM fields
   */
  def addBDMFields(df: DataFrame): DataFrame = {
    df.withColumn("bdm_create_ts", lit(util_datetime.now))
      .withColumn("bdm_datazap_id", lit(""))
      .withColumn("bdm_delete_ind", lit("N"))
  }

  def setNullableStateForAllColumns(df: DataFrame, nullable: Boolean): DataFrame = {
    df.sqlContext.createDataFrame(df.rdd, StructType(df.schema.map(_.copy(nullable = nullable))))
  }

  def make(staging_userAmountTypeXREF: DataFrame, queryApplied_basicOptional: DataFrame,
    queryApplied_basicOptional1: DataFrame): DataFrame = {
    //transformations start from here
    val transformation1 = queryApplied_basicOptional.withColumn(("StageVar"), bround(col("BASIC_PERCENTAGE") + col
    ("OPTIONAL_PERCENTAGE") + col("NON_INSURANCE_PERCENTAGE"), 3))
    val transformation2 = transformation1.withColumn(("NON_INSURANCE_PERCENTAGE")
      , when(col("StageVar") === 99.999, bround(col("NON_INSURANCE_PERCENTAGE") + 0.001, 3))
        .when(col("StageVar") === 100.001, bround(col("NON_INSURANCE_PERCENTAGE") - 0.001, 3))
        .otherwise(col("NON_INSURANCE_PERCENTAGE"))
    )

    val transformation3 = transformation2.drop("StageVar").withColumn(("StageVar"), bround(col("BASIC_PERCENTAGE") +
      col("OPTIONAL_PERCENTAGE") + col("NON_INSURANCE_PERCENTAGE"), 3))
    val transformation4 = transformation3.drop("StageVar")
    val copy1 = transformation4.withColumn(("PRODUCT_TYPE_ID")
      , when(col("BASIC_PERCENTAGE") =!= 0.000, 1)).na.drop(Array("PRODUCT_TYPE_ID"))
    val copy2 = transformation4.withColumn(("PRODUCT_TYPE_ID")
      , when(col("OPTIONAL_PERCENTAGE") =!= 0.000, 2)).na.drop(Array("PRODUCT_TYPE_ID"))
    val copy3 = transformation4.withColumn(("PRODUCT_TYPE_ID")
      , when(col("NON_INSURANCE_PERCENTAGE") =!= 0.000, 3)).na.drop(Array("PRODUCT_TYPE_ID"))
    val transformation5 = copy1.union(copy2).union(copy3)
    val transformation6 = transformation5.withColumn(("BASIC_OPTIONAL_PERCENTAGE")
      , when(col("PRODUCT_TYPE_ID") === 1, col("BASIC_PERCENTAGE"))
        .when(col("PRODUCT_TYPE_ID") === 2, col("OPTIONAL_PERCENTAGE"))
        .when(col("PRODUCT_TYPE_ID") === 3, col("NON_INSURANCE_PERCENTAGE"))
    )
    val transformation7 = transformation6.drop("BASIC_PERCENTAGE", "BASIC_UNIT_OF_MEASURE", "OPTIONAL_PERCENTAGE",
      "OPTIONAL_UNIT_OF_MEASURE", "NON_INSURANCE_UNIT_OF_MEASURE",
      "NON_INSURANCE_PERCENTAGE", "RULE_YEAR", "RULE_PERIOD", "MAX_PERIOD", "SAP_EXTRACT_DATE_TIME")

    //merge
    val transformation8 = transformation7.union(queryApplied_basicOptional1)
    //transformation8.groupBy("PRODUCT_TYPE_ID").count().show()


    //join
    val transformation9 = transformation8.join(staging_userAmountTypeXREF, Seq("BON_VALUE_TYPE", "BON_PLAN_VERSION"),
      "leftouter")
    val transformation10 = transformation9.drop("BON_VALUE_TYPE", "BON_PLAN_VERSION")
    return transformation10
  }
}

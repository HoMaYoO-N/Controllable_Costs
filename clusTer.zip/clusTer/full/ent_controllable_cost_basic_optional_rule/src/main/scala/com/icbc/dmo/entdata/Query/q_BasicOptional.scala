package com.icbc.dmo.entdata.Query

import org.apache.spark.sql.{DataFrame, SparkSession}

object q_BasicOptional {
  def applied(spark: SparkSession, staging_table1: DataFrame, staging_table2: DataFrame): DataFrame = {

    staging_table1.createOrReplaceTempView("basicOptionalRule")
    staging_table2.createOrReplaceTempView("basicOptionalRule2009p1")
    val stream = getClass.getResourceAsStream("/basicOptional.sql")
    val query = scala.io.Source.fromInputStream(stream).getLines.mkString
    val applied = spark.sql(query)
    return applied
  }
}

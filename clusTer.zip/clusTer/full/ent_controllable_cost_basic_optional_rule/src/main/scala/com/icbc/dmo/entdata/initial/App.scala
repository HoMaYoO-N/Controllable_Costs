package com.icbc.dmo.entdata.initial

import org.apache.log4j.{Logger, LogManager}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.SaveMode

import com.icbc.{util_base, util_dao}
import com.icbc.dmo.entdata.transformations
import com.icbc.dmo.entdata.Query.{q_BasicOptional, q_BasicOptional1}
import com.icbc.dmo.entdata.SourcetoStaging.{s_BasicOptionalRule, s_UserBasicOptionalRule2009p1}

import com.typesafe.config.Config

object App {



  def main(args: Array[String]): Unit = {
    val log: Logger = LogManager.getLogger(this.getClass.getName)
    implicit val (spark, config) = util_base.initSparkPipeline(args, "dmo", "basic_optional_rule")
    log.debug("SparkSession Started")

    // 1-1)read staging basic_optional_rule
    val cluster_landing_staging_path = config.getString("landing_staging_path")
    val basicOptionalRule_SourceFile=spark.read.textFile(cluster_landing_staging_path + "sap_controllable_cost/sap_cdw_basic_optional_rules-data").toDF()
    val staging_basicOptionalRule = s_BasicOptionalRule.parser(spark, basicOptionalRule_SourceFile).persist()

    // 1-2)read staging user_basic_optional_rule_2009p1
    val cluster_user_data_path = config.getString("user_data_path") + '/'
    val basicOptionalRule2009p1_SourceFile = spark.read.textFile(cluster_user_data_path + "user_input_controllable_cost/cis_basic_optional_rule_2009p1").toDF()
    val staging_basicOptionalRule2009p1 = s_UserBasicOptionalRule2009p1.parser(spark, basicOptionalRule2009p1_SourceFile).persist()

    // 1-3) read staging user_amount_type_XREF
    val userAmountTypeXREF_SourceFile = spark.read.format("csv")
      .option("inferSchema", "true")
      .load(cluster_user_data_path + "user_input_controllable_cost/cis_amount_type_xref")
      .toDF("AMOUNT_TYPE","BON_VALUE_TYPE","BON_PLAN_VERSION","EXPENSE_VALUE_TYPE","EXPENSE_PLAN_VERSION","SETTLEMENT_VALUE_TYPE","SETTLEMENT_PLAN_VERSION","BON_AMOUNT_TYPE","SETTLEMENT_AMOUNT_TYPE")

    val userAmountType_SourceFile = spark.read.format("csv")
      .option("inferSchema", "true")
      .load(cluster_user_data_path + "user_input_controllable_cost/cis_amount_type")
      .toDF("AMOUNT_TYPE_1","AMOUNT_TYPE_NAME","DW_BEG_DTE","DW_LOAD_DTE","DW_END_DTE","DELETE_IND")

    val joined_SourceFiles = userAmountType_SourceFile.join(userAmountTypeXREF_SourceFile,userAmountType_SourceFile("AMOUNT_TYPE_1")===userAmountTypeXREF_SourceFile("AMOUNT_TYPE"),"inner")
    val staging_userAmountTypeXREF = joined_SourceFiles.select(col("AMOUNT_TYPE"),col("BON_VALUE_TYPE"),col("BON_PLAN_VERSION"))

    //2-1) apply the query BasicOptional
    val queryApplied_basicOptional = q_BasicOptional.applied(spark,staging_basicOptionalRule,staging_basicOptionalRule2009p1)

    //2-2) apply the query BasicOptional1
    val queryApplied_basicOptional1 = q_BasicOptional1.applied(spark,staging_basicOptionalRule,staging_basicOptionalRule2009p1)


    val withDataStageTransformations = transformations.make(staging_userAmountTypeXREF, queryApplied_basicOptional, queryApplied_basicOptional1)
    val fixNullability = transformations.setNullableStateForAllColumns(withDataStageTransformations,false)
    val withBDMfields = transformations.addBDMFields(fixNullability)
    val finalDF = withBDMfields

    val targetMetaTable = util_dao.parquet(saveMode = SaveMode.Overwrite)
      .getOrCreateTable("entdata_finance", "control_cost_basic_optional_rule")
    val targetColumns = util_base.getSelectSQL(targetMetaTable.getSchema)
    targetMetaTable.save(finalDF.select(targetColumns: _*))
  }
}
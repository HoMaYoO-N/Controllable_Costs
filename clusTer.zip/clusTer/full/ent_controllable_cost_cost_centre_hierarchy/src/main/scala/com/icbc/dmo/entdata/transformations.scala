package com.icbc.dmo.entdata

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, length, lit, trim, udf, when}
import org.apache.spark.sql.types.{StructField, StructType}

import com.icbc.util_datetime

object transformations {

  def addBDMFields(df: DataFrame): DataFrame = {
    df.withColumn("bdm_create_ts", lit(util_datetime.now))
      .withColumn("bdm_datazap_id", lit(""))
      .withColumn("bdm_delete_ind", lit("N"))
  }

  /**
   * Set nullable property of column.
   * @param df source DataFrame
   * @param cn is the column name to change
   * @param nullable is the flag to set, such that the column is  either nullable or not
   */
  def setNullableStateOfColumn(df: DataFrame, cn: String, nullable: Boolean): DataFrame = {
    // get schema
    val schema = df.schema
    // modify [[StructField] with name `cn`
    val newSchema = StructType(schema.map {
      case StructField(c, t, _, m) if c.equals(cn) => StructField(c, t, nullable = nullable, m)
      case y: StructField                          => y
    })
    df.sqlContext.createDataFrame( df.rdd, newSchema )
  }
  def LNK_TO_JN(df: DataFrame): DataFrame = {
    //filter out those records whose COST_CENTRE_HIERARCHY_NAME is STD_ICBC
    //we want the records without COST_CENTRE_HIERARCHY_NAME of STD_ICBC
    val with_STD_ICBC_Hierarchy = df.filter(col("COST_CENTRE_HIERARCHY_NAME") =!= "STD_ICBC")

    //if Parent_Cost_Centre does not have ".", then svParentCE becomes zero. Otherwise, it will become the index just after the "."
    val getTheFirstOccuranceofDot = udf((x:String) => x.indexOf('.')+1)
    val with_svParentCE = with_STD_ICBC_Hierarchy.withColumn(("svParentCE"),getTheFirstOccuranceofDot(col("PARENT_COST_CENTRE")))

    //add a new new column COST_CENTRE_1 which is the same as COST_CENTRE. This col will be used as a filter later in transformation after Funnel(the union)
    val with_COST_CENTRE_1 = with_svParentCE.withColumn(("COST_CENTRE_1"),trim(col("COST_CENTRE")))


    //drop extra columns we do not need. Even we drop PARENT_COST_CENTRE because we want 000001 after the join
    val otherExtraColumnsDropped = with_COST_CENTRE_1
      .drop("COST_CENTRE_ID")
      .drop("COST_CENTRE_NAME")
      .drop("COST_CENTRE_NAME_ALPHA")
      .drop("COST_CENTRE_SHORT_NAME")
      .drop("COST_CENTRE_LONG_NAME")
      .drop("COST_CENTRE_MANAGER_NAME")
      .drop("PARENT_COST_CENTRE")
      .drop("SAP_EXTRACT_DATE_TIME")
    val result = otherExtraColumnsDropped
    return result
  }
  def LNK_TO_FN_ALL(df: DataFrame): DataFrame = {

    val getTheFirstOccuranceofDot = udf((x:String) => x.indexOf('.')+1)
    val with_svParentCE = df.withColumn(("svParentCE"),getTheFirstOccuranceofDot(col("PARENT_COST_CENTRE")))
    val goFromIndex0tosvParentCE = udf((prntCstCntr:String, indx:Int) => prntCstCntr.substring(0,indx-1))
    val PARENT_COST_CENTRE_FIXED_1 = with_svParentCE.withColumn(("PARENT_COST_CENTRE2")
      ,when(col("svParentCE") === 0,col("PARENT_COST_CENTRE"))
        .otherwise(goFromIndex0tosvParentCE(col("PARENT_COST_CENTRE"),col("svParentCE"))))
    val PARENT_COST_CENTRE_FIXED_2 = PARENT_COST_CENTRE_FIXED_1.drop("PARENT_COST_CENTRE")
    val PARENT_COST_CENTRE_FIXED_3 = PARENT_COST_CENTRE_FIXED_2.withColumn("PARENT_COST_CENTRE",col("PARENT_COST_CENTRE2"))
    val PARENT_COST_CENTRE_FIXED_4 = PARENT_COST_CENTRE_FIXED_3.drop("PARENT_COST_CENTRE2")
    val svParentCEDropped = PARENT_COST_CENTRE_FIXED_4.drop("svParentCE")
    val result = svParentCEDropped
    return result
  }
  def LNK_TO_FN_MISSING(df: DataFrame): DataFrame = {
    //Here is the condition:
    //(ISNULL(LNK_FRM_JN.COST_CENTRE_1) OR LNK_FRM_JN.COST_CENTRE_1='') -> meaning only take null or empty values for cost_centre1 which is nothing but copy of cost_centre
    //AND LNK_FRM_JN.COST_CENTRE_NUMERIC='0' -> In SQL Hierarchy2 we have this : CAST(TRANSLATE(SUBSTR(T.COST_CENTRE, 1, 1),'0123456789','0000000000') AS INT )AS COST_CENTRE_NUMERIC
    //AND LNK_FRM_JN.COST_CENTRE_HIERARCHY_NAME<>'STD_ICBC' -> as always, we do not want STD_ICBC
    val filteredAfterJoin = df.filter((col("COST_CENTRE_1").isNull || col("COST_CENTRE_1") === "") && col("COST_CENTRE_NUMERIC") === '0' && col("COST_CENTRE_HIERARCHY_NAME") =!= "STD_ICBC")

    //remove these cause we do not need them anymore
    val limited = filteredAfterJoin
      .drop("COST_CENTRE_1")
      .drop("COST_CENTRE_NUMERIC")

    val result = limited
    return result
  }
}
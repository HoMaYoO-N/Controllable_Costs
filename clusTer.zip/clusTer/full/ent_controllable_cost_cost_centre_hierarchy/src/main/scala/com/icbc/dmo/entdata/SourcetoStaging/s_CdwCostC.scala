package com.icbc.dmo.entdata.SourcetoStaging
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, substring, to_timestamp, trim}

object s_CdwCostC {
  def parser(spark: SparkSession, df : DataFrame): DataFrame = {
    val phase1 =
      df.withColumn("COST_CENTRE", trim(substring(df("value"), 1, 24)).cast("String"))
        .withColumn("COST_CENTRE_SHORT_NAME", trim(substring(df("value"), 25, 20)).cast("String"))
        .withColumn("COST_CENTRE_LONG_NAME",trim(substring(df("value"), 45, 40)).cast("String"))
        .withColumn("COST_CENTRE_MGR_NAME",trim(substring(df("value"), 85, 20)).cast("String"))
        .withColumn("PARENT_COST_CENTRE",trim(substring(df("value"), 105, 24)).cast("String"))
        .withColumn("SAP_EXTRACT_DATE_TIME",trim(substring(df("value"), 129, 14)))
        .withColumn("COST_CENTRE_HIER_NAME",trim(substring(df("value"), 143, 15)).cast("String"))
        .drop("value")
    val phase2 =
      phase1.withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(phase1("SAP_EXTRACT_DATE_TIME"), "/",
        "-"),"yyyyMMddHHmmss"))
    val parsedDF = phase2
    return parsedDF
  }
}
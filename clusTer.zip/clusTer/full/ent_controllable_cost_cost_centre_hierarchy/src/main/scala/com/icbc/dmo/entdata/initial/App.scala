package com.icbc.dmo.entdata.initial

import org.apache.spark._
import org.apache.log4j._
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import scala.io.Source
import scala.io.Source.fromFile
import org.apache.spark.{SparkConf, SparkException}
import org.apache.spark.sql.expressions.Window

import com.icbc.{util_base, util_dao}
import com.icbc.dmo.entdata.transformations
import com.icbc.dmo.entdata.Query.{q_CostCentreHierarchy1, q_CostCentreHierarchy2}
import com.icbc.dmo.entdata.SourcetoStaging.s_CdwCostC



object App {

  def main(args: Array[String]): Unit = {
    val log: Logger = LogManager.getLogger(this.getClass.getName)
    implicit val (spark, config) = util_base.initSparkPipeline(args, "dmo", "cost_centre_hierarchy")
    spark.conf.set("spark.sql.crossJoin.enabled", "true")

    log.debug("SparkSession Started")

    // 1-1)read staging cost_centre_hierarchy
    val cluster_landing_staging_path = config.getString("landing_staging_path")
    val costC_SourceFile = spark.read.textFile(cluster_landing_staging_path + "sap_controllable_cost/sap_cdw_costc-data").toDF()
    val staging_costCentreHierarchy = s_CdwCostC.parser(spark, costC_SourceFile).persist()



    //2-2) apply the queries
    val q1 = q_CostCentreHierarchy1.applied(spark,staging_costCentreHierarchy)
    //correct
    println("q1",q1.count())
    val qSTD = q_CostCentreHierarchy2.applied(spark,staging_costCentreHierarchy)
    println("qSTD",qSTD.count())



    val q1_toJoin = transformations.LNK_TO_JN(q1)
    println("q1_toJoin",q1_toJoin.count())
  //  q1_toJoin.orderBy(col("SAP_EXTRACT_DATE_TIME")).show(55,false)


    //do a left outer join of transformation1 and queryApplied_costCentreHierarchy_STD. Then replace the values for source_parent_cost_centre as 000001
    val afterJoin = qSTD.join(q1_toJoin, Seq("COST_CENTRE","COST_CENTRE_HIERARCHY_NAME"),"leftouter")
      .drop("SOURCE_PARENT_COST_CENTRE")
      .withColumn("SOURCE_PARENT_COST_CENTRE",lit("000001"))
    println("afterJoin",afterJoin.count())
   // afterJoin.orderBy(col("SAP_EXTRACT_DATE_TIME")).show(55,false)


    //so until here both parent_cost_centre and source_parent_cost_centre will be 000001


    val afterJoin_toFunnel = transformations.LNK_TO_FN_MISSING(afterJoin)
    //reorder the col names so that in union everything works fine
    val afterJoin_toFunnel_reorderedColNames = afterJoin_toFunnel.select("COST_CENTRE_ID","COST_CENTRE","COST_CENTRE_NAME","COST_CENTRE_NAME_ALPHA","COST_CENTRE_SHORT_NAME","COST_CENTRE_LONG_NAME","COST_CENTRE_MANAGER_NAME","SOURCE_PARENT_COST_CENTRE","SOURCE_COST_CENTRE","SAP_EXTRACT_DATE_TIME","COST_CENTRE_HIERARCHY_NAME","PARENT_COST_CENTRE")
    println("afterJoin_toFunnel_reorderedColNames",afterJoin_toFunnel_reorderedColNames.count())

    //this will be used in the Funnel(union). Branch no.2 of first transformation in DStage
    val q1_toFunnel = transformations.LNK_TO_FN_ALL(q1)
    println("q1_toFunnel",q1_toFunnel.count())
    //correct

    //Funnel(union)

    val afterFunnel = afterJoin_toFunnel_reorderedColNames.union(q1_toFunnel)

    //We add this in the end cause we think this column is actually not that important in the final tableau result
    val windowSpec  = Window.orderBy("COST_CENTRE")
    val added_sequence = afterFunnel.withColumn("COST_CENTRE_SEQUENCE",row_number.over(windowSpec))

    //changing source_cost_centre so that it is not null anymore in case of hierarchy = STD_ICBC
    val changeSourceCC = added_sequence.drop("SOURCE_COST_CENTRE").withColumn("SOURCE_COST_CENTRE",col("COST_CENTRE"))

    val nullability_fixer1 = transformations.setNullableStateOfColumn(changeSourceCC,"COST_CENTRE_ID",false)
    val nullability_fixer2 = transformations.setNullableStateOfColumn(nullability_fixer1,"COST_CENTRE",false)
    val nullability_fixer3 = transformations.setNullableStateOfColumn(nullability_fixer2,"COST_CENTRE_SEQUENCE",false)
    val nullability_fixer4 = transformations.setNullableStateOfColumn(nullability_fixer3,"COST_CENTRE_HIERARCHY_NAME",false)
    val nullability_fixer5 = transformations.setNullableStateOfColumn(nullability_fixer4,"SAP_EXTRACT_DATE_TIME",false)

    val withBDMfields = transformations.addBDMFields(nullability_fixer5)
    val finalDF = withBDMfields

    val targetMetaTable = util_dao.parquet(saveMode = SaveMode.Overwrite)
      .getOrCreateTable("entdata_finance", "control_cost_cost_centre_hierarchy")
    val targetColumns = util_base.getSelectSQL(targetMetaTable.getSchema)
    targetMetaTable.save(finalDF.select(targetColumns: _*))
  }
}
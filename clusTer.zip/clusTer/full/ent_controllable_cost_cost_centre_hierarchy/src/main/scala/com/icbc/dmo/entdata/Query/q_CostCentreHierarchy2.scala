package com.icbc.dmo.entdata.Query

import org.apache.spark.sql.{DataFrame, SparkSession}

object q_CostCentreHierarchy2 {
  def applied(spark: SparkSession, staging_table1: DataFrame): DataFrame = {

    staging_table1.createOrReplaceTempView("costCentreHierarchy")
    val stream = getClass.getResourceAsStream("/costCentreHierarchy2.sql")
    val query = scala.io.Source.fromInputStream(stream).getLines.mkString
    val applied = spark.sql(query)
    return applied
  }
}

CREATE TABLE wbs_element(
    bdm_create_ts timestamp,
    bdm_datazap_id string,
    bdm_delete_ind string,
    cost_centre_id long,
    cost_centre string,
    cost_centre_sequence int,
    cost_centre_name string,
    cost_centre_name_alpha string,
    cost_centre_short_name string,
    cost_centre_long_name string,
    cost_centre_manager_name string,
    parent_cost_centre string,
    cost_centre_hierarchy_name string,
    sap_extract_date_time timestamp,
    source_cost_centre string,
    source_parent_cost_centre string
)
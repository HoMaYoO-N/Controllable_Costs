SELECT
	CASE WHEN TRANSLATE(SUBSTR(T.COST_CENTRE, 1, 1),'0123456789','0000000000') = '0' THEN CAST(T.COST_CENTRE AS INT)
	ELSE 9876543210
	END AS COST_CENTRE_ID 
	,CASE WHEN INSTR(T.COST_CENTRE, '.') = 0 THEN RTRIM(T.COST_CENTRE)
	ELSE SUBSTR(T.COST_CENTRE, 1, INSTR(T.COST_CENTRE, '.') - 1)
	END AS COST_CENTRE 
	,CASE WHEN TRANSLATE(SUBSTR(T.COST_CENTRE, 1, 1),'0123456789','0000000000') = '0' THEN RTRIM(T.COST_CENTRE) || ' ' || RTRIM(T.COST_CENTRE_SHORT_NAME) 
	ELSE RTRIM(T.COST_CENTRE_LONG_NAME)
	END AS COST_CENTRE_NAME
	,CASE WHEN TRANSLATE(SUBSTR(T.COST_CENTRE, 1, 1),'0123456789','0000000000') = '0' THEN RTRIM(T.COST_CENTRE_SHORT_NAME) || ' - ' || RTRIM(T.COST_CENTRE) 
	ELSE RTRIM(T.COST_CENTRE_LONG_NAME)
	END AS COST_CENTRE_NAME_ALPHA 
	,RTRIM(T.COST_CENTRE_SHORT_NAME) AS COST_CENTRE_SHORT_NAME
	,RTRIM(T.COST_CENTRE_LONG_NAME) AS COST_CENTRE_LONG_NAME
	,RTRIM(T.COST_CENTRE_MGR_NAME) AS COST_CENTRE_MANAGER_NAME
	,CASE WHEN INSTR(T.PARENT_COST_CENTRE, '.') = 0 THEN RTRIM(T.PARENT_COST_CENTRE) 
	ELSE SUBSTR(T.PARENT_COST_CENTRE, 1, INSTR(T.PARENT_COST_CENTRE, '.') - 1)
	END AS PARENT_COST_CENTRE
	,TRIM(T.PARENT_COST_CENTRE) AS SOURCE_PARENT_COST_CENTRE
	,TRIM(T.COST_CENTRE) AS SOURCE_COST_CENTRE
	,T.SAP_EXTRACT_DATE_TIME
	,RTRIM(T.COST_CENTRE_HIER_NAME) AS COST_CENTRE_HIERARCHY_NAME 
FROM costCentreHierarchy T
	,(
		SELECT
			 COST_CENTRE
			,COST_CENTRE_HIER_NAME
		FROM costCentreHierarchy T2 
		) T1 
		WHERE T.COST_CENTRE_HIER_NAME = T1.COST_CENTRE_HIER_NAME 
		AND T1.COST_CENTRE = T.COST_CENTRE 

UNION ALL 
		
SELECT 
	0 AS cost_centre_id
	,'000000' AS cost_centre
	,'000000 Not Applicable' AS cost_centre_name
	,'Not Applicable 000000' AS cost_centre_name_alpha
	,'Unknown' AS cost_centre_short_name
	,'Unknown' AS cost_centre_long_name
	,'Unknown' AS cost_centre_manager_name
	,'000001' AS parent_cost_centre
	,'000001' AS SOURCE_parent_cost_centre
	,'000000' AS source_cost_centre
	,t.sap_extract_date_time
	,t.cost_centre_hier_name 
FROM costCentreHierarchy t 
WHERE t.parent_cost_centre = ''

UNION 

SELECT 
	1 AS cost_centre_id
	,'000001' AS cost_centre
	,'000001 Not Applicable' AS cost_centre_name
	,'Not Applicable 000001' AS cost_centre_name_alpha
	,'Unknown' AS cost_centre_short_name
	,'Unknown' AS cost_centre_long_name
	,'Unknown' AS cost_centre_manager_name
	,t.cost_centre AS parent_cost_centre
	,t.cost_centre AS SOURCE_parent_cost_centre
	,'000001' AS source_cost_centre
	,t.sap_extract_date_time
	,t.cost_centre_hier_name 
FROM costCentreHierarchy t 
WHERE t.parent_cost_centre = ''
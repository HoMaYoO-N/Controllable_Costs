package com.icbc.dmo.entdata.initial

import org.apache.log4j.{Logger, LogManager}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.SaveMode

import com.icbc.{util_base, util_dao}
import com.icbc.dmo.entdata.Query.q_InternalOrder
import com.icbc.dmo.entdata.SourcetoStaging.s_CdwOrders
import com.icbc.dmo.entdata.transformations.{addBDMFields, setNullableStateOfColumn}

object App {


  def main(args: Array[String]): Unit = {
    val log: Logger = LogManager.getLogger(this.getClass.getName)
    implicit val (spark, config) = util_base.initSparkPipeline(args, "dmo", "internal_order")
    log.debug("SparkSession Started")


    // 1-1)read staging table
    val cluster_landing_staging_path = config.getString("landing_staging_path")
    val internalOrder_SourceFile=spark.read.textFile(cluster_landing_staging_path + "sap_controllable_cost/sap_cdw_orders-data").toDF()
    val staging_internalOrder = s_CdwOrders.parser(spark, internalOrder_SourceFile).persist()


    //2-1) apply the query
    val queryApplied_internalOrder = q_InternalOrder.applied(spark,staging_internalOrder)

    //3) fix the nullability
    val nullability_fixer1 = setNullableStateOfColumn(queryApplied_internalOrder,"INTERNAL_ORDER_ID",false)
    val nullability_fixer2 = setNullableStateOfColumn(nullability_fixer1,"INTERNAL_ORDER_NUMBER",false)
    val nullability_fixer3 = setNullableStateOfColumn(nullability_fixer2,"SAP_EXTRACT_DATE_TIME",false)


    // 4) add bdm fields
    val withBDMfields = addBDMFields(nullability_fixer3)
    val finalDF = withBDMfields

    val targetMetaTable = util_dao.parquet(saveMode = SaveMode.Overwrite)
      .getOrCreateTable("entdata_finance", "control_cost_internal_order")
    val targetColumns = util_base.getSelectSQL(targetMetaTable.getSchema)
    println(targetColumns)
    targetMetaTable.save(finalDF.select(targetColumns: _*))
  }
}
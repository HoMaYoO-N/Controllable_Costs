package com.icbc.dmo.entdata.Query

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, to_timestamp}

object q_InternalOrder {
  def applied(spark: SparkSession, staging_table1: DataFrame): DataFrame = {

    staging_table1.createOrReplaceTempView("internalOrder")
    val stream = getClass.getResourceAsStream("/internalOrder.sql")
    val query = scala.io.Source.fromInputStream(stream).getLines.mkString
    val applied = spark.sql(query)
    val newRow = Seq((0, "000000000000", null, null, "0001-01-01 00:00:00.0"))
    val df = spark.createDataFrame(newRow)
    val withNewRowAppended = applied.union(df)
    val  withSAP_EXTRACT_DATE_TIME_Format_Fixed = withNewRowAppended
      .withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(withNewRowAppended("SAP_EXTRACT_DATE_TIME"), "/",
      "-")))
    return withSAP_EXTRACT_DATE_TIME_Format_Fixed
  }

}

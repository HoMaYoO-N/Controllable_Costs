package com.icbc.dmo.entdata.SourcetoStaging

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, substring, to_timestamp, trim}

object s_CdwOrders {
  def parser(spark: SparkSession, df: DataFrame): DataFrame = {
    val phase1 =
      df.withColumn("INTERNAL_ORDER_NUMBER", trim(substring(df("value"), 1, 12)).cast("Integer"))
        .withColumn("INTERNAL_ORDER_NAME", trim(substring(df("value"), 13, 40)).cast("String"))
        .withColumn("SAP_EXTRACT_DATE_TIME", trim(substring(df("value"), 53, 10)))
        .drop("value")
    val phase2 =
      phase1.withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(phase1("SAP_EXTRACT_DATE_TIME"), "/",
        "-")))
    val parsedDF = phase2
    return parsedDF
  }
}

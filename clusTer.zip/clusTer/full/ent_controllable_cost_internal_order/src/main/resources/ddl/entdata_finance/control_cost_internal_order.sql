CREATE TABLE control_cost_internal_order(
    INTERNAL_ORDER_ID int,
    INTERNAL_ORDER_NUMBER string,
    INTERNAL_ORDER_NAME string,
    INTERNAL_ORDER_NAME_ALPHA string,
    SAP_EXTRACT_DATE_TIME timestamp,
    bdm_create_ts timestamp,
    bdm_datazap_id string,
    bdm_delete_ind string
)
package com.icbc.dmo.entdata.Query

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, to_timestamp}
import py4j.Protocol.getNull

object q_WbsElement {
  def builder(spark: SparkSession, staging_table: DataFrame): DataFrame = {

    staging_table.createOrReplaceTempView("wbsElement")
    val stream = getClass.getResourceAsStream("/wbs_element2.sql")
    val query = scala.io.Source.fromInputStream(stream).getLines.mkString
    val applied = spark.sql(query)
    applied.printSchema()
    val newRow = Seq((0,null,null,null,null,0,"Unknown",null,null,4, "0001-01-01 00:00:00.0"))
    val df = spark.createDataFrame(newRow)
    val withNewRowAppended = applied.union(df)
    val  withSAP_EXTRACT_DATE_TIME_Format_Fixed = withNewRowAppended.withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(withNewRowAppended("SAP_EXTRACT_DATE_TIME"), "/",
      "-")))

    return withSAP_EXTRACT_DATE_TIME_Format_Fixed
  }
}
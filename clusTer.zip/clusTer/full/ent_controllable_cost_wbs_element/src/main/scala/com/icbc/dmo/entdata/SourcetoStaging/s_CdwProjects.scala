package com.icbc.dmo.entdata.SourcetoStaging

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{regexp_replace, substring, to_timestamp, trim}

object s_CdwProjects {
  def parser(spark: SparkSession, df: DataFrame): DataFrame = {
    val phase1 =
      df.withColumn("WBS_ELEMENT_EXTERNAL", trim(substring(df("value"), 0, 24)).cast("String"))
        .withColumn("WBS_ELEMENT", trim(substring(df("value"), 25, 22)).cast("String"))
        .withColumn("WBS_ELEMENT_NAME", trim(substring(df("value"), 47, 40)).cast("String"))
        .withColumn("PROJECT_DEFINITION", trim(substring(df("value"), 87, 24)).cast("String"))
        .withColumn("PROJECT_HIERARCHY", trim(substring(df("value"), 111, 1)).cast("Integer"))
        .withColumn("SAP_EXTRACT_DATE_TIME", trim(substring(df("value"), 112, 12)))
        .drop("value")
    val phase2 =
      phase1.withColumn("SAP_EXTRACT_DATE_TIME", to_timestamp(regexp_replace(phase1("SAP_EXTRACT_DATE_TIME"), "/",
        "-")))

    val parsedDF = phase2
    return parsedDF

  }

}

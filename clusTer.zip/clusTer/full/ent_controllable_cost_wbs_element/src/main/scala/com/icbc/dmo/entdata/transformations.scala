package com.icbc.dmo.entdata

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{StructField, StructType}

import com.icbc.util_datetime

object transformations {
  /**
   * Set nullable property of column.
   * @param df source DataFrame
   * @param cn is the column name to change
   * @param nullable is the flag to set, such that the column is  either nullable or not
   */
  def setNullableStateOfColumn(df: DataFrame, cn: String, nullable: Boolean): DataFrame = {
    // get schema
    val schema = df.schema
    // modify [[StructField] with name `cn`
    val newSchema = StructType(schema.map {
      case StructField(c, t, _, m) if c.equals(cn) => StructField(c, t, nullable = nullable, m)
      case y: StructField                          => y
    })
    df.sqlContext.createDataFrame( df.rdd, newSchema )
  }

  def addBDMFields(df: DataFrame): DataFrame = {
    df.withColumn("bdm_create_ts", lit(util_datetime.now))
      .withColumn("bdm_datazap_id", lit(""))
      .withColumn("bdm_delete_ind", lit("N"))
  }
}

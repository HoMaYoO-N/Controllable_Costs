CREATE TABLE wbs_element(
    bdm_create_ts timestamp,
    bdm_datazap_id string,
    bdm_delete_ind string,
    wbs_element string
    wbs_element_id bigint
    wbs_element_type string
    wbs_element_external string
    wbs_element_name string
    project_type int
    project_type_name string
    project_definition string
    project_hierarchy int
    project_definition_name string
    sap_extract_date_time timestamp
)